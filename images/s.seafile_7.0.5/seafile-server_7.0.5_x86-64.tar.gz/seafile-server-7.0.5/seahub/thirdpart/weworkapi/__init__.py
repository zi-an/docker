"""ref: https://github.com/sbzhu/weworkapi_python"""
